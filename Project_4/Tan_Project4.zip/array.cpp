﻿#include <iostream>
#include <string>
#include <cassert>
using namespace std;

bool check(int b);
int appendToAll(string a[], int n, string value);
int lookup(const string a[], int n, string target);
int positionOfMax(const string a[], int n);
int rotateLeft(string a[], int n, int pos);
int rotateRight(string a[], int n, int pos);
int flip(string a[], int n);
int differ(const string a1[], int n1, const string a2[], int n2);
int subsequence(const string a1[], int n1, const string a2[], int n2);
int lookupAny(const string a1[], int n1, const string a2[], int n2);
int partition(string a[], int n, string separator);

int main()
{
	string h[7] = { "obiwan", "minnie", "han", "simba", "", "jabba", "ariel" };
	assert(lookup(h, 7, "jabba") == 5);
	assert(lookup(h, 7, "han") == 2);
	assert(lookup(h, 2, "han") == -1);
	assert(positionOfMax(h, 7) == 3);

	string g[4] = { "obiwan", "minnie", "simba", "jabba" };
	assert(differ(h, 4, g, 4) == 2);
	assert(appendToAll(g, 4, "?") == 4 && g[0] == "obiwan?" && g[3] == "jabba?");
	assert(rotateLeft(g, 4, 1) == 1 && g[1] == "simba?" && g[3] == "minnie?");

	string e[4] = { "han", "simba", "", "jabba" };
	assert(subsequence(h, 7, e, 4) == 2);
	assert(rotateRight(e, 4, 1) == 1 && e[0] == "simba" && e[2] == "");
	
	string f[3] = { "simba", "han", "ursula" };
	assert(lookupAny(h, 7, f, 3) == 2);
	assert(flip(f, 3) == 3 && f[0] == "ursula" && f[2] == "simba");
	
	assert(partition(h, 7, "jabba") == 3);
	
	cout << "All tests succeeded" << endl;
}

int appendToAll(string a[], int n, string value)
{
	if(!check(n))
		return -1;
    for (int i = 0; i < n; i++)
	{
		a[i] += value;	//Addes the value to the end of each string
	}
	return n;
}

int lookup(const string a[], int n, string target)
{
	if(!check(n))
		return -1;
	for (int i = 0; i < n; i++)
	{
		if(a[i] == target)	//When the string is the same as the target, return the position
			return i;
	}
	return -1;
}

int positionOfMax(const string a[], int n)
{
	if(!check(n))
		return -1;
	string cur = "";
	int max = -1;
	for (int i = 0; i < n; i++)
	{
		if(cur < a[i])	//When current string is greater than previously greatest string
		{
			max = i;	//Set the max to the current position and set greatest string to current string
			cur = a[i];
		}
	}
	return max;
}

int rotateLeft(string a[], int n, int pos)
{
	if(!check(n))
		return -1;
	if(pos >= n)
		return -1;
	string save = a[pos];	//Save initial string
	for(int i = pos; i < n - 1; i++)
	{
		a[i] = a[i+1];	//Move strings left one space
	}
	a[n - 1] = save;	//Place overwritten string (initial string) to end of array
	return pos;
}

int rotateRight(string a[], int n, int pos)
{	
	if(!check(n))
		return -1;
	if(pos >= n)
		return -1;
	string save = a[pos];	//Save initial string
	for(int i = pos; i > 0; i--)
	{
		a[i] = a[i-1];	//Move strings right one space
	}
	a[0] = save;	//Place overwritten string (initial string) to start of array
	return pos;
}

int flip(string a[], int n)
{
	int end = n - 1;
	string temp = "";
	if(!check(n))
		return -1;
	for(int i = 0; i < end / 2; i++)	//Only go through half, or it will flip back to original
	{
		temp = a[end-i];	//Swap the places of the two strings
		a[end-i] = a[i];	//Use positions that are same distance from beginning and the end
		a[i] = temp;
	}
	return n;
}

int differ(const string a1[], int n1, const string a2[], int n2)
{
	if(!check(n1))
		return -1;
	if(!check(n2))
		return -1;
	int i = 0;
	while(i < n1 && i < n2)	//Repeatedly: i reaches either n1 or n2
	{
		if(a1[i] != a2[i])	//When the two are not equal, end the loop
			break;
		i++;
	}
	return i;
}

int subsequence(const string a1[], int n1, const string a2[], int n2)
{
	if(!check(n1))
		return -1;
	if(!check(n2))
		return -1;
	int increment = 0;
	for(int i = 0; i <= n1 - n2; i++)
	{
		for(increment = 0; increment < n2; increment++)
		{
			if(a1[i + increment] != a2[increment])	//If the strings do not match, end the comparison
				break;
		}
		if(increment == n2)	//If all the strings matched, return the position of the first string
			return i;
	}
	return -1;
}

int lookupAny(const string a1[], int n1, const string a2[], int n2)
{
	if(!check(n1))
		return -1;
	if(!check(n2))
		return -1;
	for(int i = 0; i < n1; i++)
	{
		for(int j = 0; j < n2; j++)
			if(a1[i] == a2[j])
				return i;	//If any of the strings in a2 match a string in a1, return the position in a1
	}
	return -1;
}

int partition(string a[], int n, string separator)
{
	if(!check(n))
		return -1;
	int i = 0;
	for(int count = 0; count < n; count++)	//Ensure that the method will not run into an infinite loop
	{
		if(a[i] < separator)
		{
			rotateRight(a, n, i);	//When the string is less than separator, move it to front of array
			i++;	//Add i to move to next position, as the string is moved to the front of array
		}
		else if (a[i] > separator)
		{
			rotateLeft(a, n, i);	//When the string is greater than separator, move it to end of array (Do not increment i; Check same spot, as string will be different)
		}
		else
			i++;	//If the string is equal to the separator, only increment i
	}
	for(int b = 0; b < n; b++)
	{
		if(a[b] >= separator)	//Return the first position that the string is not less than separator
			return b;
	}
	return n;
}

bool check(int b)	//Ensures that the number input is not negative
{
	if(b < 0)
		return false;
	return true;
}