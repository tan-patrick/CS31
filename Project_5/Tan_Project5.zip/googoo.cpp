#include <iostream>
#include <cassert>
#include <cctype>
#include <string>
#include <iostream>
#include <cstring>
using namespace std;

const int MAX_WORD_LENGTH = 20;

int normalizeCriteria(int distance[], char word1[][MAX_WORD_LENGTH+1], char word2[][MAX_WORD_LENGTH+1], int nCriteria);
int moveIntToEnd(int a[], int n, int pos);
int moveCharToEnd(char a[][MAX_WORD_LENGTH+1], int n, int pos);
void allLower(char c[][MAX_WORD_LENGTH + 1], int n);
bool letter(char l[][MAX_WORD_LENGTH + 1], int pos);
int similar(int dis[], char setOne[][MAX_WORD_LENGTH+1], char setTwo[][MAX_WORD_LENGTH+1], int criteria);
int computeScore(const int distance[], const char word1[][MAX_WORD_LENGTH+1], const char word2[][MAX_WORD_LENGTH+1], int nCriteria, const char document[]);

int main()
{
		const int TEST1_NCRITERIA = 4;
	int test1dist[TEST1_NCRITERIA] = {
		2,           4,          1,           13
	};
	char test1w1[TEST1_NCRITERIA][MAX_WORD_LENGTH+1] = {
		"mad",       "deranged", "nefarious", "have"
	};
	char test1w2[TEST1_NCRITERIA][MAX_WORD_LENGTH+1] = {
		"scientist", "robot",    "plot",      "mad"
	};
	assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"The mad UCLA scientist unleashed a deranged evil giant robot.") == 2);
	assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"The mad UCLA scientist unleashed    a deranged robot.") == 2);
	assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"**** 2012 ****") == 0);
	assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"  What a NEFARIOUS plot!") == 1);
	assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"deranged deranged robot deranged robot robot") == 1);
	assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"Two mad scientists have deranged-robot fever.") == 0);
	cout << "All tests succeeded" << endl;
}

int normalizeCriteria(int distance[], char word1[][MAX_WORD_LENGTH+1], char word2[][MAX_WORD_LENGTH+1], int nCriteria)
{
	int endCriteria = nCriteria;
	int i = 0;
	
	allLower(word1, nCriteria);		//makes all words all lower case
	allLower(word2, nCriteria);
	endCriteria = similar(distance, word1, word2, nCriteria);  //checks for identical criteria

	while(i != endCriteria) //Moves criteria with non positive distances out of valid criteria
	{
		if(distance[i] <= 0)
		{
			moveIntToEnd(distance, nCriteria, i);
			moveCharToEnd(word1, nCriteria, i);
			moveCharToEnd(word2, nCriteria, i);
			endCriteria--;
		}
		else
			i++;
	}

	i = 0;

	while(i != endCriteria) //Moves criteria with an empty string out of valid criteria
	{
		if(word1[i][0] == '\0' || word2[i][0] == '\0')
		{
			moveIntToEnd(distance, nCriteria, i);
			moveCharToEnd(word1, nCriteria, i);
			moveCharToEnd(word2, nCriteria, i);
			endCriteria--;
		}
		else
			i++;
	}

	i = 0;

	while(i != endCriteria)  //Moves criteria with a non alphabetical character out of valid criteria
	{
		if(!letter(word1, i) || !letter(word2,i))
		{
			moveIntToEnd(distance, nCriteria, i);
			moveCharToEnd(word1, nCriteria, i);
			moveCharToEnd(word2, nCriteria, i);
			endCriteria--;
		}
		else
			i++;
	}

	return endCriteria; //Returns number of valid criteria
}

int computeScore(const int distance[], const char word1[][MAX_WORD_LENGTH+1], const char word2[][MAX_WORD_LENGTH+1], int nCriteria, const char document[])
{
	int score = 0;

	char check[201][201]; //Creates two-dimensional array check (maximum number of document is 200, +1 for '0' '\0'
	int num = 0;
	int loc = 0;

	for(int k = 0; document[k] != '\0'; k++)  //Puts all of the words in the document into a normalized form
	{
		if(isalpha(document[k])) //Keeps on alphabeticals and makes them lower case
		{
			check[num][loc] = tolower(document[k]);
			loc++;
		}
		if(document[k] == ' ') //Controls the location in the array to keep the proper number of words in the correct order
		{
			check[num][loc] = '\0';
			while(!isalpha(document[k+1]) && (document[k+1] != '\0'))
				k++;
			if(document[k+1] != '\0')
			{
				loc = 0;
				num++;
			}
		}
	}
	check[num][loc] = '\0';
	bool exit = false;

	for(int j = 0; j < nCriteria; j++) //Counts number of criteria fulfilled
	{
		for(int i = 0; i <= num; i++)
		{
			if(exit == true) //Breaks out of loop when criteria was matched
			{
				exit = false;
				break;
			}
			if(strcmp(check[i], word1[j]) == 0) //Checks if criteria matched by a word in the document
			{
				for(int k = 1; k <= distance[j] && i + k <= num; k++)
				{
					if(strcmp(check[i+k], word2[j]) == 0) //Checks if second word shows up within distance
					{
						score++;
						exit = true;
						break;
					}
				}
			}
		}
	}

	return score;
}

int moveIntToEnd(int a[], int n, int pos)
{
	if(n < 0)
		return -1;
	if(pos >= n || pos < 0)
		return -1;
	int save = a[pos];	//Save initial integer
	for(int i = pos; i < n - 1; i++)
	{
		a[i] = a[i+1];	//Move array left one space
	}
	a[n - 1] = save;	//Place overwritten integer (initial integer) to end of array
	return 1;
}

int moveCharToEnd(char a[][MAX_WORD_LENGTH+1], int n, int pos)
{
	if(n < 0)
		return -1;
	if(pos >= n || pos < 0)
		return -1;
	char save[1][MAX_WORD_LENGTH+1]; //Saves initial string
	
	strcpy(save[0], a[pos]);
	for(int i = pos; i < n - 1; i++)
	{
		strcpy(a[i], a[i+1]); //Moves all strings left one space
	}
	strcpy(a[n - 1], save[0]); //Replaces string at end
	return 1;
}

void allLower(char c[][MAX_WORD_LENGTH + 1], int n)
{
	for(int i = 0; i != n; i++) //Makes all characters in the input array to lower case
	{
		for(int j = 0; j != MAX_WORD_LENGTH + 1 && c[i][j] != '\0'; j++) 
		{
			c[i][j] = tolower(c[i][j]);
		}
	}
}

bool letter(char l[][MAX_WORD_LENGTH + 1], int pos)
{
	int a = 0;
	while(l[pos][a] != '\0') //Checks if all characters are alphabetical
	{
		if(!isalpha(l[pos][a]))
		{
			return false;
		}
		a++;
	}
	return true;
}

int similar(int dis[], char setOne[][MAX_WORD_LENGTH+1], char setTwo[][MAX_WORD_LENGTH+1], int criteria)
{
	//Checks if the criteria are equal and moves the criteria with lesser distance out of valid criteria

	int startCriteria = criteria;

	for(int i = 0; i != criteria; i++)
	{
		for(int j = 0; j != criteria; j++)
		{
			if(j != i)
			{
				if(strcmp(setOne[i], setOne[j]) == 0 && strcmp(setOne[i], setTwo[j])) 
				{
					if(dis[i] < dis[j])
					{
						moveIntToEnd(dis, startCriteria, i);
						moveCharToEnd(setOne, startCriteria, i);
						moveCharToEnd(setTwo, startCriteria, i);
						criteria--;
					}
					else
					{
						moveIntToEnd(dis, startCriteria, i);
						moveCharToEnd(setOne, startCriteria, i);
						moveCharToEnd(setTwo, startCriteria, i);
						criteria--;
					}
				}
			}
		}
	}
	return criteria;
}